package com.ekoehler.expressivecutout.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONObject

/** Backing store for every behaviour setting. */
private val Context.behaviourDataStore: DataStore<Preferences> by preferencesDataStore(name = "behaviour_prefs")

/** How the cutout behaves when the device is in horizontal/landscape orientation. */
enum class HorizontalCutoutMode { HIDDEN, NORMAL_ONLY, STICK_TO_CAMERA, CENTER }

/**
 * What a tap or swipe on the island does. [NONE] ignores the gesture; [EXPAND] and
 * [SHRINK] grow or collapse the island; [OPEN_APP] launches the event's app; [DISMISS] removes
 * the current event; [OPEN_INBOX] displays active notifications; the next/previous actions browse
 * without dismissing the notifications.
 */
enum class GestureAction { NONE, EXPAND, SHRINK, OPEN_APP, DISMISS, OPEN_INBOX, NEXT_NOTIFICATION, PREVIOUS_NOTIFICATION }

/**
 * Which side of the primary pill the satellite bubble sits on when the island is split. The primary
 * pill always keeps its camera-anchored centre, so only the bubble moves.
 */
enum class SatellitePosition { LEFT, RIGHT }

/**
 * Which kinds of event the cutout keeps up until dismissed, without the user pressing the pin
 * button. Ordered to match the settings selector.
 */
enum class PinNotificationsMode {
    NONE,
    NOTIFICATIONS,
    SYSTEM_EVENTS,
    BOTH;

    /** True when notifications are pinned on arrival. */
    val pinsNotifications: Boolean get() = this == NOTIFICATIONS || this == BOTH

    /** True when system events are pinned on arrival. */
    val pinsSystemEvents: Boolean get() = this == SYSTEM_EVENTS || this == BOTH
}

/**
 * How the island's appear / expand / collapse motion is driven. [EXPRESSIVE] uses Material 3
 * MotionScheme-style spatial springs (its speed comes from [AnimationSpeed]); [EASE_IN_OUT] uses a
 * standard ease-in-out tween whose length is the animation-duration slider. Ordered to match the
 * settings selector so the ordinal doubles as the segment index.
 */
enum class AnimationStyle { EXPRESSIVE, EASE_IN_OUT }

/**
 * The spatial-spring speed used when [AnimationStyle.EXPRESSIVE] is active, mirroring MotionScheme's
 * slow / default / fast spatial specs. Ordered to match the settings selector.
 */
enum class AnimationSpeed { SLOW, DEFAULT, FAST }

/**
 * How much the expressive spatial springs overshoot (their damping): a big, obvious bounce, the
 * tuned normal, or the barely-there stock MotionScheme feel. Ordered to match the settings selector.
 */
enum class AnimationBounce { BIG, NORMAL, SMALL }

/**
 * How the action buttons (and reply buttons) react to a press. [SCALE] springs down and back like
 * a squish; [EXPAND] briefly widens the button by a few dp instead. Ordered to match the settings
 * selector so the ordinal doubles as the segment index.
 */
enum class ActionButtonAnimation { SCALE, EXPAND }

/**
 * What tapping the resting (event-less) empty pill does. [NONE] only plays the press animation;
 * [OPEN_APP] launches the app chosen in [BehaviourSettings.showsWhenEmptyClickPackage];
 * [OPEN_CENTER] shows the shortcut grid and [OPEN_INBOX] displays active notifications. Ordered to match the settings selector.
 */
enum class EmptyClickAction { NONE, OPEN_APP, OPEN_CENTER, OPEN_INBOX }

/**
 * How the island behaves once expanded. [expandedAutoCollapse] chooses between collapsing after
 * [expandedCollapseSeconds] or staying until tapped. When that shrink happens,
 * [expandedDisappearOnShrink] decides whether the island disappears entirely (true) or returns
 * to the normal cutout (false).
 */
data class BehaviourSettings(
    val cutoutEnabled: Boolean = DEFAULT_CUTOUT_ENABLED,
    val hideOnLockscreen: Boolean = DEFAULT_HIDE_ON_LOCKSCREEN,
    val hideInLandscape: Boolean = DEFAULT_HIDE_IN_LANDSCAPE,
    val horizontalCutoutMode: HorizontalCutoutMode = DEFAULT_HORIZONTAL_CUTOUT_MODE,
    val animationStyle: AnimationStyle = DEFAULT_ANIMATION_STYLE,
    val animationSpeed: AnimationSpeed = DEFAULT_ANIMATION_SPEED,
    val animationBounce: AnimationBounce = DEFAULT_ANIMATION_BOUNCE,
    val actionButtonAnimation: ActionButtonAnimation = DEFAULT_ACTION_BUTTON_ANIMATION,
    val animationDurationMs: Int = DEFAULT_ANIMATION_DURATION_MS,
    val normalDurationSeconds: Int = DEFAULT_NORMAL_SECONDS,
    val expandedAutoCollapse: Boolean = DEFAULT_AUTO_COLLAPSE,
    val expandedCollapseSeconds: Int = DEFAULT_COLLAPSE_SECONDS,
    val expandedDisappearOnShrink: Boolean = DEFAULT_DISAPPEAR_ON_SHRINK,
    val notificationsAutoExpand: Boolean = DEFAULT_NOTIFICATIONS_AUTO_EXPAND,
    val ignoreSilentNotifications: Boolean = DEFAULT_IGNORE_SILENT_NOTIFICATIONS,
    val pinNotificationsMode: PinNotificationsMode = DEFAULT_PIN_NOTIFICATIONS_MODE,
    val showActionButtons: Boolean = DEFAULT_SHOW_ACTION_BUTTONS,
    val toastOnAction: Boolean = DEFAULT_TOAST_ON_ACTION,
    val normalTap: GestureAction = DEFAULT_NORMAL_TAP,
    val normalSwipeUp: GestureAction = DEFAULT_NORMAL_SWIPE_UP,
    val expandedTap: GestureAction = DEFAULT_EXPANDED_TAP,
    val expandedSwipeUp: GestureAction = DEFAULT_EXPANDED_SWIPE_UP,
    val expandedSwipeDown: GestureAction = DEFAULT_EXPANDED_SWIPE_DOWN,
    val normalSwipeLeft: GestureAction = DEFAULT_SWIPE_SIDEWAYS,
    val normalSwipeRight: GestureAction = DEFAULT_SWIPE_SIDEWAYS,
    val expandedSwipeLeft: GestureAction = DEFAULT_SWIPE_SIDEWAYS,
    val expandedSwipeRight: GestureAction = DEFAULT_SWIPE_SIDEWAYS,
    val showsWhenEmpty: Boolean = SHOWS_WHEN_EMPTY,
    val showEmptyCutout: Boolean = SHOW_EMPTY_CUTOUT,
    val hiddenEmptyWidthPercent: Int = DEFAULT_HIDDEN_EMPTY_WIDTH_PERCENT,
    val showsWhenEmptyClickAction: EmptyClickAction = DEFAULT_EMPTY_CLICK_ACTION,
    val showsWhenEmptyClickPackage: String? = null,
    val showStatusDot: Boolean = DEFAULT_SHOW_STATUS_DOT,
    val statusDotSide: StatusDotSide = DEFAULT_STATUS_DOT_SIDE,
    val centerShortcuts: List<CenterShortcut> = CenterShortcut.DEFAULTS,
    val centerShowLabels: Boolean = CENTER_SHOW_LABELS,
    val centerFillContainers: Boolean = CENTER_FILL_CONTAINERS,
    val centerThemedIcons: Boolean = CENTER_THEMED_ICONS,
    val vibrateOnTap: Boolean = DEFAULT_VIBRATE_ON_TAP,
    val hapticsOnPop: Boolean = DEFAULT_HAPTICS_ON_POP,
    val dismissNotifications: Boolean = DEFAULT_DISMISS_NOTIFICATIONS,
    val displayWhileDnd: Boolean = DEFAULT_DISPLAY_WHILE_DND,
    val alertOnNotification: Boolean = DEFAULT_ALERT_ON_NOTIFICATION,
    val splitIslandEnabled: Boolean = DEFAULT_SPLIT_ISLAND_ENABLED,
    val satellitePosition: SatellitePosition = DEFAULT_SATELLITE_POSITION,
) {
    /**
     * Whether the resting pill takes part in the overlay at all: SWE and the cutout are on, and the
     * pill is either drawn or hidden with a click action left to catch. A hidden pill with no action
     * would be an invisible strip that only blocks the status bar.
     */
    val emptyPillActive: Boolean
        get() = showsWhenEmpty && cutoutEnabled &&
            (showEmptyCutout || showsWhenEmptyClickAction != EmptyClickAction.NONE)

    companion object {
        const val DEFAULT_CUTOUT_ENABLED = true
        const val DEFAULT_HIDE_ON_LOCKSCREEN = false
        const val DEFAULT_HIDE_IN_LANDSCAPE = false
        const val DEFAULT_VIBRATE_ON_TAP = true
        const val DEFAULT_HAPTICS_ON_POP = false
        val DEFAULT_HORIZONTAL_CUTOUT_MODE = HorizontalCutoutMode.CENTER
        const val DEFAULT_ANIMATION_DURATION_MS = 220
        val DEFAULT_ANIMATION_STYLE = AnimationStyle.EXPRESSIVE
        val DEFAULT_ANIMATION_SPEED = AnimationSpeed.DEFAULT
        val DEFAULT_ANIMATION_BOUNCE = AnimationBounce.NORMAL
        val DEFAULT_ACTION_BUTTON_ANIMATION = ActionButtonAnimation.SCALE
        const val DEFAULT_NORMAL_SECONDS = 3
        const val DEFAULT_AUTO_COLLAPSE = true
        const val DEFAULT_COLLAPSE_SECONDS = 5
        const val DEFAULT_DISAPPEAR_ON_SHRINK = false
        const val DEFAULT_NOTIFICATIONS_AUTO_EXPAND = false
        const val DEFAULT_IGNORE_SILENT_NOTIFICATIONS = false
        val DEFAULT_PIN_NOTIFICATIONS_MODE = PinNotificationsMode.NONE
        const val DEFAULT_SHOW_ACTION_BUTTONS = true
        const val DEFAULT_TOAST_ON_ACTION = true
        val DEFAULT_NORMAL_TAP = GestureAction.EXPAND
        val DEFAULT_NORMAL_SWIPE_UP = GestureAction.NONE
        val DEFAULT_EXPANDED_TAP = GestureAction.OPEN_APP
        val DEFAULT_EXPANDED_SWIPE_UP = GestureAction.SHRINK
        val DEFAULT_EXPANDED_SWIPE_DOWN = GestureAction.NONE
        val DEFAULT_SWIPE_SIDEWAYS = GestureAction.DISMISS
        const val DEFAULT_SPLIT_ISLAND_ENABLED = true
        val DEFAULT_SATELLITE_POSITION = SatellitePosition.RIGHT
        const val MIN_ANIMATION_DURATION_MS = 0
        const val MAX_ANIMATION_DURATION_MS = 1000
        const val MIN_NORMAL_SECONDS = 1
        const val MAX_NORMAL_SECONDS = 10
        const val MIN_COLLAPSE_SECONDS = 1
        const val MAX_COLLAPSE_SECONDS = 15
        const val SHOWS_WHEN_EMPTY = false
        const val SHOW_EMPTY_CUTOUT = true
        const val DEFAULT_HIDDEN_EMPTY_WIDTH_PERCENT = 30
        val DEFAULT_EMPTY_CLICK_ACTION = EmptyClickAction.NONE
        const val DEFAULT_SHOW_STATUS_DOT = true
        val DEFAULT_STATUS_DOT_SIDE = StatusDotSide.LEFT
        const val CENTER_SHOW_LABELS = true
        const val CENTER_FILL_CONTAINERS = false
        const val CENTER_THEMED_ICONS = false
        const val DEFAULT_DISMISS_NOTIFICATIONS = false
        const val DEFAULT_DISPLAY_WHILE_DND = false
        const val DEFAULT_ALERT_ON_NOTIFICATION = false
    }
}

/** Persists [BehaviourSettings], always emitting a clamped collapse delay. */
class BehaviourPreferences(private val context: Context) : JsonSerializable {

    val settings: Flow<BehaviourSettings> = context.behaviourDataStore.data.map { prefs ->
        val rawMode = prefs[HORIZONTAL_CUTOUT_MODE]
        val hideLandscape = prefs[HIDE_IN_LANDSCAPE] ?: BehaviourSettings.DEFAULT_HIDE_IN_LANDSCAPE
        val horizontalCutoutMode = if (rawMode != null) {
            runCatching { HorizontalCutoutMode.valueOf(rawMode) }.getOrDefault(BehaviourSettings.DEFAULT_HORIZONTAL_CUTOUT_MODE)
        } else if (hideLandscape) {
            HorizontalCutoutMode.HIDDEN
        } else {
            BehaviourSettings.DEFAULT_HORIZONTAL_CUTOUT_MODE
        }

        BehaviourSettings(
            cutoutEnabled = prefs[CUTOUT_ENABLED] ?: BehaviourSettings.DEFAULT_CUTOUT_ENABLED,
            hideOnLockscreen = prefs[HIDE_ON_LOCKSCREEN] ?: BehaviourSettings.DEFAULT_HIDE_ON_LOCKSCREEN,
            hideInLandscape = hideLandscape || (horizontalCutoutMode == HorizontalCutoutMode.HIDDEN),
            horizontalCutoutMode = horizontalCutoutMode,
            animationStyle = prefs[ANIMATION_STYLE]
                ?.let { runCatching { AnimationStyle.valueOf(it) }.getOrNull() }
                ?: BehaviourSettings.DEFAULT_ANIMATION_STYLE,
            animationSpeed = prefs[ANIMATION_SPEED]
                ?.let { runCatching { AnimationSpeed.valueOf(it) }.getOrNull() }
                ?: BehaviourSettings.DEFAULT_ANIMATION_SPEED,
            animationBounce = prefs[ANIMATION_BOUNCE]
                ?.let { runCatching { AnimationBounce.valueOf(it) }.getOrNull() }
                ?: BehaviourSettings.DEFAULT_ANIMATION_BOUNCE,
            actionButtonAnimation = prefs[ACTION_BUTTON_ANIMATION]
                ?.let { runCatching { ActionButtonAnimation.valueOf(it) }.getOrNull() }
                ?: BehaviourSettings.DEFAULT_ACTION_BUTTON_ANIMATION,
            animationDurationMs = (prefs[ANIMATION_DURATION_MS] ?: BehaviourSettings.DEFAULT_ANIMATION_DURATION_MS)
                .coerceIn(BehaviourSettings.MIN_ANIMATION_DURATION_MS, BehaviourSettings.MAX_ANIMATION_DURATION_MS),
            normalDurationSeconds = (prefs[NORMAL_SECONDS] ?: BehaviourSettings.DEFAULT_NORMAL_SECONDS)
                .coerceIn(BehaviourSettings.MIN_NORMAL_SECONDS, BehaviourSettings.MAX_NORMAL_SECONDS),
            expandedAutoCollapse = prefs[AUTO_COLLAPSE] ?: BehaviourSettings.DEFAULT_AUTO_COLLAPSE,
            expandedCollapseSeconds = (prefs[COLLAPSE_SECONDS] ?: BehaviourSettings.DEFAULT_COLLAPSE_SECONDS)
                .coerceIn(BehaviourSettings.MIN_COLLAPSE_SECONDS, BehaviourSettings.MAX_COLLAPSE_SECONDS),
            expandedDisappearOnShrink = prefs[DISAPPEAR_ON_SHRINK] ?: BehaviourSettings.DEFAULT_DISAPPEAR_ON_SHRINK,
            notificationsAutoExpand = prefs[NOTIF_AUTO_EXPAND] ?: BehaviourSettings.DEFAULT_NOTIFICATIONS_AUTO_EXPAND,
            ignoreSilentNotifications = prefs[IGNORE_SILENT_NOTIFICATIONS] ?: BehaviourSettings.DEFAULT_IGNORE_SILENT_NOTIFICATIONS,
            pinNotificationsMode = prefs[PIN_NOTIFICATIONS_MODE]
                ?.let { runCatching { PinNotificationsMode.valueOf(it) }.getOrNull() }
                ?: BehaviourSettings.DEFAULT_PIN_NOTIFICATIONS_MODE,
            showActionButtons = prefs[SHOW_ACTION_BUTTONS] ?: BehaviourSettings.DEFAULT_SHOW_ACTION_BUTTONS,
            toastOnAction = prefs[TOAST_ON_ACTION] ?: BehaviourSettings.DEFAULT_TOAST_ON_ACTION,
            normalTap = prefs[GESTURE_NORMAL_TAP]
                ?.let { runCatching { GestureAction.valueOf(it) }.getOrNull() }
                ?: BehaviourSettings.DEFAULT_NORMAL_TAP,
            normalSwipeUp = prefs[GESTURE_NORMAL_SWIPE_UP]
                ?.let { runCatching { GestureAction.valueOf(it) }.getOrNull() }
                ?: BehaviourSettings.DEFAULT_NORMAL_SWIPE_UP,
            expandedTap = prefs[GESTURE_EXPANDED_TAP]
                ?.let { runCatching { GestureAction.valueOf(it) }.getOrNull() }
                ?: BehaviourSettings.DEFAULT_EXPANDED_TAP,
            expandedSwipeUp = prefs[GESTURE_EXPANDED_SWIPE_UP]
                ?.let { runCatching { GestureAction.valueOf(it) }.getOrNull() }
                ?: if (prefs[LEGACY_SHRINK_ON_SWIPE_UP] == false) GestureAction.NONE else GestureAction.SHRINK,
            expandedSwipeDown = prefs[GESTURE_EXPANDED_SWIPE_DOWN]
                ?.let { runCatching { GestureAction.valueOf(it) }.getOrNull() }
                ?: BehaviourSettings.DEFAULT_EXPANDED_SWIPE_DOWN,
            normalSwipeLeft = prefs[GESTURE_NORMAL_SWIPE_LEFT]
                ?.let { runCatching { GestureAction.valueOf(it) }.getOrNull() }
                ?: legacySwipeAction(prefs, left = true),
            normalSwipeRight = prefs[GESTURE_NORMAL_SWIPE_RIGHT]
                ?.let { runCatching { GestureAction.valueOf(it) }.getOrNull() }
                ?: legacySwipeAction(prefs, left = false),
            expandedSwipeLeft = prefs[GESTURE_EXPANDED_SWIPE_LEFT]
                ?.let { runCatching { GestureAction.valueOf(it) }.getOrNull() }
                ?: legacySwipeAction(prefs, left = true),
            expandedSwipeRight = prefs[GESTURE_EXPANDED_SWIPE_RIGHT]
                ?.let { runCatching { GestureAction.valueOf(it) }.getOrNull() }
                ?: legacySwipeAction(prefs, left = false),
            showsWhenEmpty = prefs[SHOWS_WHEN_EMPTY] ?: BehaviourSettings.SHOWS_WHEN_EMPTY,
            showEmptyCutout = prefs[SHOW_EMPTY_CUTOUT] ?: BehaviourSettings.SHOW_EMPTY_CUTOUT,
            hiddenEmptyWidthPercent = (prefs[HIDDEN_EMPTY_WIDTH_PERCENT] ?: BehaviourSettings.DEFAULT_HIDDEN_EMPTY_WIDTH_PERCENT)
                .coerceIn(IslandDimensions.MIN_WIDTH_PERCENT, IslandDimensions.MAX_WIDTH_PERCENT),
            showsWhenEmptyClickAction = prefs[SHOWS_WHEN_EMPTY_CLICK_ACTION]
                ?.let { runCatching { EmptyClickAction.valueOf(it) }.getOrNull() }
                ?: BehaviourSettings.DEFAULT_EMPTY_CLICK_ACTION,
            showsWhenEmptyClickPackage = prefs[SHOWS_WHEN_EMPTY_CLICK_PACKAGE],
            showStatusDot = prefs[SHOW_STATUS_DOT] ?: BehaviourSettings.DEFAULT_SHOW_STATUS_DOT,
            statusDotSide = prefs[STATUS_DOT_SIDE]
                ?.let { runCatching { StatusDotSide.valueOf(it) }.getOrNull() }
                ?: BehaviourSettings.DEFAULT_STATUS_DOT_SIDE,
            centerShortcuts = CenterShortcut.decodeList(prefs[CENTER_SHORTCUTS]),
            centerShowLabels = prefs[CENTER_SHOW_LABELS] ?: BehaviourSettings.CENTER_SHOW_LABELS,
            centerFillContainers = prefs[CENTER_FILL_CONTAINERS] ?: BehaviourSettings.CENTER_FILL_CONTAINERS,
            centerThemedIcons = prefs[CENTER_THEMED_ICONS] ?: BehaviourSettings.CENTER_THEMED_ICONS,
            vibrateOnTap = prefs[VIBRATE_ON_TAP] ?: BehaviourSettings.DEFAULT_VIBRATE_ON_TAP,
            /** If enabled, haptic feedback fires when the cutout appears and disappears */
            hapticsOnPop = prefs[HAPTICS_ON_POP] ?: BehaviourSettings.DEFAULT_HAPTICS_ON_POP,
            /** If enabled, remove Android notification pop-ups */
            dismissNotifications = prefs[DISMISS_NOTIFICATIONS] ?: BehaviourSettings.DEFAULT_DISMISS_NOTIFICATIONS,
            /** If enabled, notification cutout appears even when Do not disturb is enabled */
            displayWhileDnd = prefs[DISPLAY_WHILE_DND] ?: BehaviourSettings.DEFAULT_DISPLAY_WHILE_DND,
            /** If enabled, the island rings/vibrates itself when a new notification surfaces */
            alertOnNotification = prefs[ALERT_ON_NOTIFICATION] ?: BehaviourSettings.DEFAULT_ALERT_ON_NOTIFICATION,
            /** If enabled, a displaced event stays visible in a satellite bubble beside the pill */
            splitIslandEnabled = prefs[SPLIT_ISLAND_ENABLED] ?: BehaviourSettings.DEFAULT_SPLIT_ISLAND_ENABLED,
            satellitePosition = prefs[SATELLITE_POSITION]
                ?.let { runCatching { SatellitePosition.valueOf(it) }.getOrNull() }
                ?: BehaviourSettings.DEFAULT_SATELLITE_POSITION,
        )
    }

    /**
     * The sideways-swipe action for a user who never set the per-direction gestures, derived from
     * the old global swipe-to-dismiss switch and its LEFT / RIGHT / BOTH direction so an upgrade
     * keeps their behaviour.
     */
    private fun legacySwipeAction(prefs: Preferences, left: Boolean): GestureAction {
        if (prefs[LEGACY_SWIPE_TO_DISMISS] == false) return GestureAction.NONE
        val excludedDirection = if (left) "RIGHT" else "LEFT"
        return if (prefs[LEGACY_SWIPE_DISMISS_DIRECTION] == excludedDirection) GestureAction.NONE
        else BehaviourSettings.DEFAULT_SWIPE_SIDEWAYS
    }

    /** Exports the current, fully-resolved [BehaviourSettings] (defaults and clamping applied) as a JSON string. */
    override suspend fun toJson(): String {
        val s = settings.first()
        return JSONObject().apply {
            put("cutoutEnabled", s.cutoutEnabled)
            put("hideOnLockscreen", s.hideOnLockscreen)
            put("hideInLandscape", s.hideInLandscape)
            put("horizontalCutoutMode", s.horizontalCutoutMode.name)
            put("animationStyle", s.animationStyle.name)
            put("animationSpeed", s.animationSpeed.name)
            put("animationBounce", s.animationBounce.name)
            put("actionButtonAnimation", s.actionButtonAnimation.name)
            put("animationDurationMs", s.animationDurationMs)
            put("normalDurationSeconds", s.normalDurationSeconds)
            put("expandedAutoCollapse", s.expandedAutoCollapse)
            put("expandedCollapseSeconds", s.expandedCollapseSeconds)
            put("expandedDisappearOnShrink", s.expandedDisappearOnShrink)
            put("notificationsAutoExpand", s.notificationsAutoExpand)
            put("ignoreSilentNotifications", s.ignoreSilentNotifications)
            put("pinNotificationsMode", s.pinNotificationsMode.name)
            put("showActionButtons", s.showActionButtons)
            put("toastOnAction", s.toastOnAction)
            put("normalTap", s.normalTap.name)
            put("normalSwipeUp", s.normalSwipeUp.name)
            put("expandedTap", s.expandedTap.name)
            put("expandedSwipeUp", s.expandedSwipeUp.name)
            put("expandedSwipeDown", s.expandedSwipeDown.name)
            put("normalSwipeLeft", s.normalSwipeLeft.name)
            put("normalSwipeRight", s.normalSwipeRight.name)
            put("expandedSwipeLeft", s.expandedSwipeLeft.name)
            put("expandedSwipeRight", s.expandedSwipeRight.name)
            put("showsWhenEmpty", s.showsWhenEmpty)
            put("showEmptyCutout", s.showEmptyCutout)
            put("hiddenEmptyWidthPercent", s.hiddenEmptyWidthPercent)
            put("showsWhenEmptyClickAction", s.showsWhenEmptyClickAction.name)
            put("showsWhenEmptyClickPackage", s.showsWhenEmptyClickPackage ?: JSONObject.NULL)
            put("showStatusDot", s.showStatusDot)
            put("statusDotSide", s.statusDotSide.name)
            put("centerShortcuts", CenterShortcut.encodeList(s.centerShortcuts))
            put("centerShowLabels", s.centerShowLabels)
            put("centerFillContainers", s.centerFillContainers)
            put("centerThemedIcons", s.centerThemedIcons)
            put("vibrateOnTap", s.vibrateOnTap)
            put("hapticsOnPop", s.hapticsOnPop)
            put("dismissNotifications", s.dismissNotifications)
            put("displayWhileDnd", s.displayWhileDnd)
            put("alertOnNotification", s.alertOnNotification)
            put("splitIslandEnabled", s.splitIslandEnabled)
            put("satellitePosition", s.satellitePosition.name)
        }.toString()
    }

    /**
     * Applies the [BehaviourSettings] object exported by [toJson]; absent fields are left as-is.
     * Enums are validated (an unknown name is skipped), ranges are clamped, and the nullable icon /
     * colour / package fields clear their key on a JSON null. The [HIDE_IN_LANDSCAPE] key is written
     * alongside [HORIZONTAL_CUTOUT_MODE] to keep the pair the read path derives from consistent.
     */
    override suspend fun fromJson(json: String) {
        val obj = JSONObject(json)
        context.behaviourDataStore.edit {
            if (obj.has("cutoutEnabled")) it[CUTOUT_ENABLED] = obj.getBoolean("cutoutEnabled")
            if (obj.has("hideOnLockscreen")) it[HIDE_ON_LOCKSCREEN] = obj.getBoolean("hideOnLockscreen")
            if (obj.has("hideInLandscape")) it[HIDE_IN_LANDSCAPE] = obj.getBoolean("hideInLandscape")
            parseEnum<HorizontalCutoutMode>(obj, "horizontalCutoutMode")?.let { mode ->
                it[HORIZONTAL_CUTOUT_MODE] = mode.name
                it[HIDE_IN_LANDSCAPE] = (mode == HorizontalCutoutMode.HIDDEN) || (it[HIDE_IN_LANDSCAPE] ?: false)
            }
            parseEnum<AnimationStyle>(obj, "animationStyle")?.let { s -> it[ANIMATION_STYLE] = s.name }
            parseEnum<AnimationSpeed>(obj, "animationSpeed")?.let { s -> it[ANIMATION_SPEED] = s.name }
            parseEnum<AnimationBounce>(obj, "animationBounce")?.let { b -> it[ANIMATION_BOUNCE] = b.name }
            parseEnum<ActionButtonAnimation>(obj, "actionButtonAnimation")?.let { a -> it[ACTION_BUTTON_ANIMATION] = a.name }
            if (obj.has("animationDurationMs")) it[ANIMATION_DURATION_MS] = obj.getInt("animationDurationMs")
                .coerceIn(BehaviourSettings.MIN_ANIMATION_DURATION_MS, BehaviourSettings.MAX_ANIMATION_DURATION_MS)
            if (obj.has("normalDurationSeconds")) it[NORMAL_SECONDS] = obj.getInt("normalDurationSeconds")
                .coerceIn(BehaviourSettings.MIN_NORMAL_SECONDS, BehaviourSettings.MAX_NORMAL_SECONDS)
            if (obj.has("expandedAutoCollapse")) it[AUTO_COLLAPSE] = obj.getBoolean("expandedAutoCollapse")
            if (obj.has("expandedCollapseSeconds")) it[COLLAPSE_SECONDS] = obj.getInt("expandedCollapseSeconds")
                .coerceIn(BehaviourSettings.MIN_COLLAPSE_SECONDS, BehaviourSettings.MAX_COLLAPSE_SECONDS)
            if (obj.has("expandedDisappearOnShrink")) it[DISAPPEAR_ON_SHRINK] = obj.getBoolean("expandedDisappearOnShrink")
            if (obj.has("notificationsAutoExpand")) it[NOTIF_AUTO_EXPAND] = obj.getBoolean("notificationsAutoExpand")
            if (obj.has("ignoreSilentNotifications")) it[IGNORE_SILENT_NOTIFICATIONS] = obj.getBoolean("ignoreSilentNotifications")
            parseEnum<PinNotificationsMode>(obj, "pinNotificationsMode")?.let { m -> it[PIN_NOTIFICATIONS_MODE] = m.name }
            if (obj.has("showActionButtons")) it[SHOW_ACTION_BUTTONS] = obj.getBoolean("showActionButtons")
            if (obj.has("toastOnAction")) it[TOAST_ON_ACTION] = obj.getBoolean("toastOnAction")
            if (obj.has("shrinkOnSwipeUp")) it[LEGACY_SHRINK_ON_SWIPE_UP] = obj.getBoolean("shrinkOnSwipeUp")
            parseEnum<GestureAction>(obj, "normalTap")?.let { a -> it[GESTURE_NORMAL_TAP] = a.name }
            parseEnum<GestureAction>(obj, "normalSwipeUp")?.let { a -> it[GESTURE_NORMAL_SWIPE_UP] = a.name }
            parseEnum<GestureAction>(obj, "expandedTap")?.let { a -> it[GESTURE_EXPANDED_TAP] = a.name }
            parseEnum<GestureAction>(obj, "expandedSwipeUp")?.let { a -> it[GESTURE_EXPANDED_SWIPE_UP] = a.name }
            parseEnum<GestureAction>(obj, "expandedSwipeDown")?.let { a -> it[GESTURE_EXPANDED_SWIPE_DOWN] = a.name }
            parseEnum<GestureAction>(obj, "normalSwipeLeft")?.let { a -> it[GESTURE_NORMAL_SWIPE_LEFT] = a.name }
            parseEnum<GestureAction>(obj, "normalSwipeRight")?.let { a -> it[GESTURE_NORMAL_SWIPE_RIGHT] = a.name }
            parseEnum<GestureAction>(obj, "expandedSwipeLeft")?.let { a -> it[GESTURE_EXPANDED_SWIPE_LEFT] = a.name }
            parseEnum<GestureAction>(obj, "expandedSwipeRight")?.let { a -> it[GESTURE_EXPANDED_SWIPE_RIGHT] = a.name }
            if (obj.has("swipeToDismiss")) it[LEGACY_SWIPE_TO_DISMISS] = obj.getBoolean("swipeToDismiss")
            obj.optString("swipeDismissDirection").takeIf(String::isNotEmpty)
                ?.let { d -> it[LEGACY_SWIPE_DISMISS_DIRECTION] = d }
            if (obj.has("splitIslandEnabled")) it[SPLIT_ISLAND_ENABLED] = obj.getBoolean("splitIslandEnabled")
            parseEnum<SatellitePosition>(obj, "satellitePosition")?.let { p -> it[SATELLITE_POSITION] = p.name }
            if (obj.has("showsWhenEmpty")) it[SHOWS_WHEN_EMPTY] = obj.getBoolean("showsWhenEmpty")
            if (obj.has("showEmptyCutout")) it[SHOW_EMPTY_CUTOUT] = obj.getBoolean("showEmptyCutout")
            if (obj.has("hiddenEmptyWidthPercent")) it[HIDDEN_EMPTY_WIDTH_PERCENT] = obj.getInt("hiddenEmptyWidthPercent")
                .coerceIn(IslandDimensions.MIN_WIDTH_PERCENT, IslandDimensions.MAX_WIDTH_PERCENT)
            parseEnum<EmptyClickAction>(obj, "showsWhenEmptyClickAction")?.let { a -> it[SHOWS_WHEN_EMPTY_CLICK_ACTION] = a.name }
            if (obj.has("showsWhenEmptyClickPackage")) {
                val pkg = if (obj.isNull("showsWhenEmptyClickPackage")) null
                else obj.optString("showsWhenEmptyClickPackage").takeIf { s -> s.isNotEmpty() }
                if (pkg == null) it.remove(SHOWS_WHEN_EMPTY_CLICK_PACKAGE) else it[SHOWS_WHEN_EMPTY_CLICK_PACKAGE] = pkg
            }
            if (obj.has("showStatusDot")) it[SHOW_STATUS_DOT] = obj.getBoolean("showStatusDot")
            parseEnum<StatusDotSide>(obj, "statusDotSide")?.let { d -> it[STATUS_DOT_SIDE] = d.name }
            if (obj.has("centerShortcuts") && !obj.isNull("centerShortcuts")) {
                it[CENTER_SHORTCUTS] = obj.getString("centerShortcuts")
            }
            if (obj.has("centerShowLabels")) it[CENTER_SHOW_LABELS] = obj.getBoolean("centerShowLabels")
            if (obj.has("centerFillContainers")) it[CENTER_FILL_CONTAINERS] = obj.getBoolean("centerFillContainers")
            if (obj.has("centerThemedIcons")) it[CENTER_THEMED_ICONS] = obj.getBoolean("centerThemedIcons")
            if (obj.has("vibrateOnTap")) it[VIBRATE_ON_TAP] = obj.getBoolean("vibrateOnTap")
            if (obj.has("hapticsOnPop")) it[HAPTICS_ON_POP] = obj.getBoolean("hapticsOnPop")
            if (obj.has("dismissNotifications")) it[DISMISS_NOTIFICATIONS] = obj.getBoolean("dismissNotifications")
            if (obj.has("displayWhileDnd")) it[DISPLAY_WHILE_DND] = obj.getBoolean("displayWhileDnd")
            if (obj.has("alertOnNotification")) it[ALERT_ON_NOTIFICATION] = obj.getBoolean("alertOnNotification")
        }
    }

    /** Reads [field] as the name of enum [T]; returns null if absent, JSON-null, or an unknown name. */
    private inline fun <reified T : Enum<T>> parseEnum(obj: JSONObject, field: String): T? {
        if (!obj.has(field) || obj.isNull(field)) return null
        return runCatching { enumValueOf<T>(obj.optString(field)) }.getOrNull()
    }

    suspend fun setCutoutEnabled(enabled: Boolean) = context.behaviourDataStore.edit {
        it[CUTOUT_ENABLED] = enabled
    }

    suspend fun setHideOnLockscreen(enabled: Boolean) = context.behaviourDataStore.edit {
        it[HIDE_ON_LOCKSCREEN] = enabled
    }

    /**
     * Keeps the landscape switch and [HorizontalCutoutMode] in step: turning it on forces the mode
     * to [HorizontalCutoutMode.HIDDEN], since "hide in landscape" is that mode under an older name.
     * Mirrored by [setHorizontalCutoutMode].
     */
    suspend fun setHideInLandscape(enabled: Boolean) = context.behaviourDataStore.edit {
        it[HIDE_IN_LANDSCAPE] = enabled
        if (enabled) {
            it[HORIZONTAL_CUTOUT_MODE] = HorizontalCutoutMode.HIDDEN.name
        }
    }

    /**
     * Keeps [HorizontalCutoutMode] and the older landscape switch in step, so a reader of either
     * sees the same thing. Mirrors [setHideInLandscape].
     */
    suspend fun setHorizontalCutoutMode(mode: HorizontalCutoutMode) = context.behaviourDataStore.edit {
        it[HORIZONTAL_CUTOUT_MODE] = mode.name
        it[HIDE_IN_LANDSCAPE] = (mode == HorizontalCutoutMode.HIDDEN)
    }

    suspend fun setAnimationStyle(style: AnimationStyle) = context.behaviourDataStore.edit {
        it[ANIMATION_STYLE] = style.name
    }

    suspend fun setAnimationSpeed(speed: AnimationSpeed) = context.behaviourDataStore.edit {
        it[ANIMATION_SPEED] = speed.name
    }

    suspend fun setAnimationBounce(bounce: AnimationBounce) = context.behaviourDataStore.edit {
        it[ANIMATION_BOUNCE] = bounce.name
    }

    suspend fun setActionButtonAnimation(animation: ActionButtonAnimation) = context.behaviourDataStore.edit {
        it[ACTION_BUTTON_ANIMATION] = animation.name
    }

    /**
     * Clamps to the range the settings slider offers, so an imported settings file can't leave an
     * animation length the UI has no way to correct.
     */
    suspend fun setAnimationDurationMs(ms: Int) = context.behaviourDataStore.edit {
        it[ANIMATION_DURATION_MS] = ms.coerceIn(
            BehaviourSettings.MIN_ANIMATION_DURATION_MS,
            BehaviourSettings.MAX_ANIMATION_DURATION_MS,
        )
    }

    /** If enabled, dismiss notifications automatically */
    suspend fun setDismissNotifications(enabled: Boolean) = context.behaviourDataStore.edit {
        it[DISMISS_NOTIFICATIONS] = enabled
    }

    /**
     * Clamps to the range the settings slider offers, so an imported settings file can't leave a
     * duration the UI has no way to correct.
     */
    suspend fun setNormalDurationSeconds(seconds: Int) = context.behaviourDataStore.edit {
        it[NORMAL_SECONDS] = seconds.coerceIn(
            BehaviourSettings.MIN_NORMAL_SECONDS,
            BehaviourSettings.MAX_NORMAL_SECONDS,
        )
    }

    suspend fun setAutoCollapse(enabled: Boolean) = context.behaviourDataStore.edit {
        it[AUTO_COLLAPSE] = enabled
    }

    /**
     * Clamps to the range the settings slider offers, so an imported settings file can't leave a
     * collapse delay the UI has no way to correct.
     */
    suspend fun setCollapseSeconds(seconds: Int) = context.behaviourDataStore.edit {
        it[COLLAPSE_SECONDS] = seconds.coerceIn(
            BehaviourSettings.MIN_COLLAPSE_SECONDS,
            BehaviourSettings.MAX_COLLAPSE_SECONDS,
        )
    }

    suspend fun setDisappearOnShrink(enabled: Boolean) = context.behaviourDataStore.edit {
        it[DISAPPEAR_ON_SHRINK] = enabled
    }

    suspend fun setNotificationsAutoExpand(enabled: Boolean) = context.behaviourDataStore.edit {
        it[NOTIF_AUTO_EXPAND] = enabled
    }

    suspend fun setIgnoreSilentNotifications(enabled: Boolean) = context.behaviourDataStore.edit {
        it[IGNORE_SILENT_NOTIFICATIONS] = enabled
    }

    suspend fun setPinNotificationsMode(mode: PinNotificationsMode) = context.behaviourDataStore.edit {
        it[PIN_NOTIFICATIONS_MODE] = mode.name
    }

    suspend fun setShowActionButtons(enabled: Boolean) = context.behaviourDataStore.edit {
        it[SHOW_ACTION_BUTTONS] = enabled
    }

    suspend fun setToastOnAction(enabled: Boolean) = context.behaviourDataStore.edit {
        it[TOAST_ON_ACTION] = enabled
    }

    suspend fun setNormalTap(action: GestureAction) = context.behaviourDataStore.edit {
        it[GESTURE_NORMAL_TAP] = action.name
    }

    suspend fun setNormalSwipeUp(action: GestureAction) = context.behaviourDataStore.edit {
        it[GESTURE_NORMAL_SWIPE_UP] = action.name
    }

    suspend fun setExpandedTap(action: GestureAction) = context.behaviourDataStore.edit {
        it[GESTURE_EXPANDED_TAP] = action.name
    }

    suspend fun setExpandedSwipeUp(action: GestureAction) = context.behaviourDataStore.edit {
        it[GESTURE_EXPANDED_SWIPE_UP] = action.name
    }

    suspend fun setExpandedSwipeDown(action: GestureAction) = context.behaviourDataStore.edit {
        it[GESTURE_EXPANDED_SWIPE_DOWN] = action.name
    }

    suspend fun setNormalSwipeLeft(action: GestureAction) = context.behaviourDataStore.edit {
        it[GESTURE_NORMAL_SWIPE_LEFT] = action.name
    }

    suspend fun setNormalSwipeRight(action: GestureAction) = context.behaviourDataStore.edit {
        it[GESTURE_NORMAL_SWIPE_RIGHT] = action.name
    }

    suspend fun setExpandedSwipeLeft(action: GestureAction) = context.behaviourDataStore.edit {
        it[GESTURE_EXPANDED_SWIPE_LEFT] = action.name
    }

    suspend fun setExpandedSwipeRight(action: GestureAction) = context.behaviourDataStore.edit {
        it[GESTURE_EXPANDED_SWIPE_RIGHT] = action.name
    }

    suspend fun setSplitIslandEnabled(enabled: Boolean) = context.behaviourDataStore.edit {
        it[SPLIT_ISLAND_ENABLED] = enabled
    }

    suspend fun setSatellitePosition(position: SatellitePosition) = context.behaviourDataStore.edit {
        it[SATELLITE_POSITION] = position.name
    }

    suspend fun setShowsWhenEmpty(enabled: Boolean) = context.behaviourDataStore.edit {
        it[SHOWS_WHEN_EMPTY] = enabled
    }

    suspend fun setShowEmptyCutout(enabled: Boolean) = context.behaviourDataStore.edit {
        it[SHOW_EMPTY_CUTOUT] = enabled
    }

    /** Clamps to the island's width range, so the hidden tap area is never narrower or wider than a pill can be. */
    suspend fun setHiddenEmptyWidthPercent(percent: Int) = context.behaviourDataStore.edit {
        it[HIDDEN_EMPTY_WIDTH_PERCENT] = percent.coerceIn(
            IslandDimensions.MIN_WIDTH_PERCENT,
            IslandDimensions.MAX_WIDTH_PERCENT,
        )
    }

    suspend fun setShowStatusDot(enabled: Boolean) = context.behaviourDataStore.edit {
        it[SHOW_STATUS_DOT] = enabled
    }

    suspend fun setStatusDotSide(side: StatusDotSide) = context.behaviourDataStore.edit {
        it[STATUS_DOT_SIDE] = side.name
    }

    suspend fun setShowsWhenEmptyClickAction(action: EmptyClickAction) = context.behaviourDataStore.edit {
        it[SHOWS_WHEN_EMPTY_CLICK_ACTION] = action.name
    }

    /**
     * Stores the package the empty pill opens, or removes the key entirely for null so no app is
     * bound to the tap.
     */
    suspend fun setShowsWhenEmptyClickPackage(packageName: String?) = context.behaviourDataStore.edit {
        if (packageName == null) it.remove(SHOWS_WHEN_EMPTY_CLICK_PACKAGE)
        else it[SHOWS_WHEN_EMPTY_CLICK_PACKAGE] = packageName
    }

    /** Persist the ordered set of shortcuts shown in the expanded "center". */
    suspend fun setCenterShortcuts(shortcuts: List<CenterShortcut>) = context.behaviourDataStore.edit {
        it[CENTER_SHORTCUTS] = CenterShortcut.encodeList(shortcuts)
    }

    /** Whether each center shortcut shows its name beneath it. */
    suspend fun setCenterShowLabels(enabled: Boolean) = context.behaviourDataStore.edit {
        it[CENTER_SHOW_LABELS] = enabled
    }

    /** Whether each center shortcut's coloured container fills its slot (pill) or stays a disc. */
    suspend fun setCenterFillContainers(enabled: Boolean) = context.behaviourDataStore.edit {
        it[CENTER_FILL_CONTAINERS] = enabled
    }

    /** Whether app shortcuts in the center use their themed (monochrome) icon. */
    suspend fun setCenterThemedIcons(enabled: Boolean) = context.behaviourDataStore.edit {
        it[CENTER_THEMED_ICONS] = enabled
    }

    /** Sets whether the cutout vibrates on tap */
    suspend fun setVibrateOnTap(enabled: Boolean) = context.behaviourDataStore.edit {
        it[VIBRATE_ON_TAP] = enabled
    }

    /** Sets whether haptic feedback fires when the cutout appears and disappears */
    suspend fun setHapticsOnPop(enabled: Boolean) = context.behaviourDataStore.edit {
        it[HAPTICS_ON_POP] = enabled
    }

    /** Set if notifications appear while Do not disturb is on */
    suspend fun setDisplayWhileDnd(enabled: Boolean) = context.behaviourDataStore.edit {
        it[DISPLAY_WHILE_DND] = enabled
    }

    /** If enabled, the island rings/vibrates itself when a new notification surfaces */
    suspend fun setAlertOnNotification(enabled: Boolean) = context.behaviourDataStore.edit {
        it[ALERT_ON_NOTIFICATION] = enabled
    }

    private companion object {
        val CUTOUT_ENABLED = booleanPreferencesKey("cutout_enabled")
        val HIDE_ON_LOCKSCREEN = booleanPreferencesKey("hide_on_lockscreen")
        val HIDE_IN_LANDSCAPE = booleanPreferencesKey("hide_in_landscape")
        val HORIZONTAL_CUTOUT_MODE = stringPreferencesKey("horizontal_cutout_mode")
        val ANIMATION_STYLE = stringPreferencesKey("animation_style")
        val ANIMATION_SPEED = stringPreferencesKey("animation_speed")
        val ANIMATION_BOUNCE = stringPreferencesKey("animation_bounce")
        val ACTION_BUTTON_ANIMATION = stringPreferencesKey("action_button_animation")
        val ANIMATION_DURATION_MS = intPreferencesKey("animation_duration_ms")
        val NORMAL_SECONDS = intPreferencesKey("normal_duration_seconds")
        val AUTO_COLLAPSE = booleanPreferencesKey("expanded_auto_collapse")
        val COLLAPSE_SECONDS = intPreferencesKey("expanded_collapse_seconds")
        val DISAPPEAR_ON_SHRINK = booleanPreferencesKey("expanded_disappear_on_shrink")
        val NOTIF_AUTO_EXPAND = booleanPreferencesKey("notifications_auto_expand")
        val IGNORE_SILENT_NOTIFICATIONS = booleanPreferencesKey("ignore_silent_notifications")
        val PIN_NOTIFICATIONS_MODE = stringPreferencesKey("pin_notifications_mode")
        val SHOW_ACTION_BUTTONS = booleanPreferencesKey("show_action_buttons")
        val TOAST_ON_ACTION = booleanPreferencesKey("toast_on_action")
        val LEGACY_SHRINK_ON_SWIPE_UP = booleanPreferencesKey("shrink_on_swipe_up")
        val GESTURE_NORMAL_TAP = stringPreferencesKey("gesture_normal_tap")
        val GESTURE_NORMAL_SWIPE_UP = stringPreferencesKey("gesture_normal_swipe_up")
        val GESTURE_EXPANDED_TAP = stringPreferencesKey("gesture_expanded_tap")
        val GESTURE_EXPANDED_SWIPE_UP = stringPreferencesKey("gesture_expanded_swipe_up")
        val GESTURE_EXPANDED_SWIPE_DOWN = stringPreferencesKey("gesture_expanded_swipe_down")
        val GESTURE_NORMAL_SWIPE_LEFT = stringPreferencesKey("gesture_normal_swipe_left")
        val GESTURE_NORMAL_SWIPE_RIGHT = stringPreferencesKey("gesture_normal_swipe_right")
        val GESTURE_EXPANDED_SWIPE_LEFT = stringPreferencesKey("gesture_expanded_swipe_left")
        val GESTURE_EXPANDED_SWIPE_RIGHT = stringPreferencesKey("gesture_expanded_swipe_right")
        val LEGACY_SWIPE_TO_DISMISS = booleanPreferencesKey("swipe_to_dismiss")
        val LEGACY_SWIPE_DISMISS_DIRECTION = stringPreferencesKey("swipe_dismiss_direction")
        val SHOWS_WHEN_EMPTY = booleanPreferencesKey("shows_when_empty")
        val SHOW_EMPTY_CUTOUT = booleanPreferencesKey("show_empty_cutout")
        val HIDDEN_EMPTY_WIDTH_PERCENT = intPreferencesKey("hidden_empty_width_percent")
        val SHOW_STATUS_DOT = booleanPreferencesKey("show_status_dot")
        val STATUS_DOT_SIDE = stringPreferencesKey("status_dot_side")
        val SHOWS_WHEN_EMPTY_CLICK_ACTION = stringPreferencesKey("shows_when_empty_click_action")
        val SHOWS_WHEN_EMPTY_CLICK_PACKAGE = stringPreferencesKey("shows_when_empty_click_package")
        val CENTER_SHORTCUTS = stringPreferencesKey("center_shortcuts")
        val CENTER_SHOW_LABELS = booleanPreferencesKey("center_show_labels")
        val CENTER_FILL_CONTAINERS = booleanPreferencesKey("center_fill_containers")
        val CENTER_THEMED_ICONS = booleanPreferencesKey("center_themed_icons")
        val VIBRATE_ON_TAP = booleanPreferencesKey("vibrate_on_tap")
        val HAPTICS_ON_POP = booleanPreferencesKey("haptics_on_pop")
        val DISMISS_NOTIFICATIONS = booleanPreferencesKey("dismiss_notifications")
        val DISPLAY_WHILE_DND = booleanPreferencesKey("display_while_dnd")
        val ALERT_ON_NOTIFICATION = booleanPreferencesKey("alert_on_notification")
        val SPLIT_ISLAND_ENABLED = booleanPreferencesKey("split_island_enabled")
        val SATELLITE_POSITION = stringPreferencesKey("satellite_position")
    }
}
